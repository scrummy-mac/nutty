import React, { useEffect, useState, useRef } from 'react';
import './index.css';
import logo from './Nutty Numbers.svg';
import nigel from './nigel.svg';

export default function App() {
  const [isLowered, setIsLowered] = useState(false);
  const logoRef = useRef(null);
  const featuresRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      if (logoRef.current && featuresRef.current) {
        const logoRect = logoRef.current.getBoundingClientRect();
        const featuresRect = featuresRef.current.getBoundingClientRect();
        const logoQuarter = logoRect.top + (logoRect.height * 0.25);
        
        setIsLowered(logoQuarter >= featuresRect.top);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const startPosition = 33;
  const endPosition = 66;
  const logoPosition = isLowered ? endPosition : startPosition;

  return (
    <main className="bg-bone text-blackForest font-sans min-h-screen flex flex-col md:flex-row tracking-tight">
      {/* Left Section - Logo Section */}
      <section className="w-full md:w-[42%] h-screen md:h-auto relative">
        <div className="absolute w-48 h-48 right-8 top-12 md:hidden">
          <img 
            src={nigel} 
            alt="Nigel" 
            className="w-full h-full object-contain"
          />
        </div>
        <div 
          ref={logoRef}
          className="md:fixed w-full md:w-[42%] h-full md:h-screen flex items-center justify-center transition-all duration-500 ease-in-out" 
          style={{ 
            top: `${logoPosition}%`,
            transform: 'translateY(-50%)'
          }}
        >
          <img 
            src={logo} 
            alt="Nutty Numbers Logo" 
            className="w-[85%] md:w-[95%] h-auto mt-[58rem] md:mt-0"
          />
        </div>
      </section>

      {/* Right Section - Content Section */}
      <section className="w-full md:w-[58%] overflow-y-auto">
        {/* Hero Section */}
        <section className="py-6 md:py-8 px-6 md:px-8 text-center md:text-right relative">
          <img 
            src={nigel} 
            alt="Nigel" 
            className="hidden md:block absolute left-36 top-[3rem] w-80 h-auto transform hover:rotate-3 transition-transform duration-300"
          />
          <h1 className="text-4xl font-bold mb-3 md:mb-4 tracking-tighter">Nutty to Savvy</h1>
          <p className="text-lg mb-6 md:mb-8 font-satoshi-italic tracking-tight">
            Demystifying financial analysis
          </p>
          <div className="flex justify-center md:justify-end px-4 md:px-8">
            <button className="bg-mutedGold text-blackForest font-semibold py-3 w-full md:w-48 rounded-lg hover:bg-blackForest hover:text-mutedGold transition-all duration-300 transform hover:scale-105">
              Embark
            </button>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-8 md:py-12 px-6 md:px-8">
          <h2 ref={featuresRef} className="text-4xl font-semibold tracking-tighter">Purpose</h2>
          <p className="mt-2 text-lg max-w-2xl tracking-tight">
            Nutty Numbers empowers small businesses with financial insights and smart recommendations.
          </p>
          <div className="mt-8 md:mt-10 grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            <div className="flex flex-col">
              <h3 className="text-xl font-semibold mb-2 tracking-tight">Pricing Optimization</h3>
              <p className="tracking-tight">AI-driven suggestions to set optimal prices and maximize your profit margins.</p>
            </div>
            <div className="flex flex-col">
              <h3 className="text-xl font-semibold mb-2 tracking-tight">Inventory Recommendations</h3>
              <p className="tracking-tight">Smart alerts and insights to maintain healthy stock levels and avoid shortages.</p>
            </div>
            <div className="flex flex-col">
              <h3 className="text-xl font-semibold mb-2 tracking-tight">Financial Clarity</h3>
              <p className="tracking-tight">Clear dashboards and reports that make your financial data easy to understand.</p>
            </div>
          </div>
        </section>

        {/* Integrations Section */}
        <section className="py-8 md:py-12 px-6 md:px-8">
          <h2 className="text-4xl font-semibold tracking-tighter mb-6 md:mb-8">Integrations</h2>
          <div className="flex flex-col md:flex-row justify-center gap-4 md:gap-8">
            <button className="bg-mutedGold text-blackForest font-semibold py-3 w-full md:w-48 rounded-lg hover:bg-blackForest hover:text-mutedGold transition-all duration-300 transform hover:scale-105">
              Square
            </button>
            <button className="bg-mutedGold text-blackForest font-semibold py-3 w-full md:w-48 rounded-lg hover:bg-blackForest hover:text-mutedGold transition-all duration-300 transform hover:scale-105">
              QuickBooks
            </button>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-8 md:py-12 px-6 md:px-8">
          <h2 className="text-4xl font-semibold tracking-tighter">Pricing</h2>
          <p className="mt-2 text-lg max-w-xl tracking-tight">
            Flexible plans for businesses at every stage.
          </p>
          <div className="mt-8 md:mt-10 grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 px-4 md:px-0">
            <div className="border-t border-b md:border border-blackForest/20 rounded-none md:rounded-lg p-6 flex flex-col hover:border-blackForest/40 transition-colors duration-300 w-full">
              <h3 className="text-xl font-semibold mb-1 tracking-tight">Novice</h3>
              <p className="text-4xl font-bold mb-4 tracking-tighter">free</p>
              <ul className="text-sm mb-6 space-y-2 list-disc list-inside tracking-tight">
                <li>Basic analytics</li>
                <li>Up to 50 products</li>
                <li>Email support</li>
              </ul>
              <button className="mt-auto bg-mutedGold text-blackForest font-medium py-2 w-full rounded-lg hover:bg-blackForest hover:text-mutedGold transition-all duration-300 transform hover:scale-105">
                Select
              </button>
            </div>
            <div className="border-t border-b md:border border-blackForest/20 rounded-none md:rounded-lg p-6 flex flex-col hover:border-blackForest/40 transition-colors duration-300 w-full">
              <h3 className="text-xl font-semibold mb-1 tracking-tight">Savant</h3>
              <p className="text-4xl font-bold mb-4 tracking-tighter">$29<span className="text-base font-normal">/mo</span></p>
              <ul className="text-sm mb-6 space-y-2 list-disc list-inside tracking-tight">
                <li>All Novice features</li>
                <li>Advanced analytics</li>
                <li>Inventory forecasting</li>
                <li>Priority support</li>
              </ul>
              <button className="mt-auto bg-mutedGold text-blackForest font-medium py-2 w-full rounded-lg hover:bg-blackForest hover:text-mutedGold transition-all duration-300 transform hover:scale-105">
                Select
              </button>
            </div>
          </div>
        </section>
      </section>
    </main>
  );
}